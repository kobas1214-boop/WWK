import { Search } from "lucide-react";

export function SearchFilters() {
  return (
    <div className="panel">
      <div className="filters">
        <div className="field">
          <label>案件番号</label>
          <input placeholder="WWK-260001" />
        </div>
        <div className="field">
          <label>顧客名</label>
          <input placeholder="青山邸" />
        </div>
        <div className="field">
          <label>商品名</label>
          <input placeholder="壁面収納" />
        </div>
        <div className="field">
          <label>材種</label>
          <input placeholder="ウォールナット" />
        </div>
      </div>
      <div className="actions" style={{ marginTop: 12 }}>
        <button className="button primary">
          <Search size={17} aria-hidden />
          検索
        </button>
      </div>
    </div>
  );
}
