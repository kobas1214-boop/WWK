import Link from "next/link";
import type { ReactNode } from "react";
import { BarChart3, FileText, FolderKanban, Images, ReceiptText, Settings, Users } from "lucide-react";

const nav = [
  { href: "/", label: "ダッシュボード", icon: BarChart3 },
  { href: "/projects", label: "案件一覧", icon: FolderKanban },
  { href: "/drawings", label: "図面一覧", icon: FileText },
  { href: "/customers", label: "顧客管理", icon: Users },
  { href: "/estimates", label: "見積管理", icon: ReceiptText },
  { href: "/settings", label: "設定", icon: Settings }
];

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <Link href="/" className="brand" aria-label="WWK Works Cloud">
          <div className="mark">WWK</div>
          <div>
            <strong>WWK Works Cloud</strong>
            <span>WOOD WORK KOBAYASHI</span>
          </div>
        </Link>
        <nav className="nav">
          {nav.map((item) => {
            const Icon = item.icon;
            return (
              <Link href={item.href} key={item.href}>
                <Icon size={18} aria-hidden />
                {item.label}
              </Link>
            );
          })}
          <Link href="/projects/p1">
            <Images size={18} aria-hidden />
            案件詳細
          </Link>
        </nav>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
