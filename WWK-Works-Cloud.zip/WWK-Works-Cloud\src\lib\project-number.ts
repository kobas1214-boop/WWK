export function createProjectNo(sequence: number, date = new Date()) {
  const yy = String(date.getFullYear()).slice(-2);
  return `WWK-${yy}${String(sequence).padStart(4, "0")}`;
}
