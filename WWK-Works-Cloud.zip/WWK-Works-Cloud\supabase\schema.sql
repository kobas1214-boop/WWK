create extension if not exists "pgcrypto";

create type project_status as enum ('見積中', '受注', '製作中', '納品済');
create type drawing_type as enum ('PDF', 'DXF', 'DWG', 'JPEG', 'PNG');
create type photo_stage as enum ('製作前', '製作中', '完成後');

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  contact_name text,
  phone text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.project_sequences (
  year int primary key,
  last_number int not null default 0
);

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  project_no text not null unique,
  customer_id uuid references public.customers(id) on delete restrict,
  customer_name text not null,
  product_name text not null,
  wood_species text,
  status project_status not null default '見積中',
  due_date date,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.drawings (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  file_name text not null,
  file_type drawing_type not null,
  storage_path text not null,
  extracted_dimensions text[] not null default '{}',
  extracted_wood_species text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table public.photos (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  stage photo_stage not null,
  storage_path text not null,
  caption text,
  created_at timestamptz not null default now()
);

create table public.estimates (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  version int not null default 1,
  title text not null,
  subtotal numeric(12, 0) not null default 0,
  tax numeric(12, 0) not null default 0,
  total numeric(12, 0) not null default 0,
  pdf_storage_path text,
  created_at timestamptz not null default now()
);

create table public.estimate_items (
  id uuid primary key default gen_random_uuid(),
  estimate_id uuid not null references public.estimates(id) on delete cascade,
  item_name text not null,
  quantity numeric(10, 2) not null default 1,
  unit text not null default '式',
  unit_price numeric(12, 0) not null default 0,
  amount numeric(12, 0) generated always as (quantity * unit_price) stored
);

create or replace function public.issue_project_no()
returns text
language plpgsql
security definer
as $$
declare
  yy text := to_char(now(), 'YY');
  yyyy int := extract(year from now())::int;
  next_no int;
begin
  insert into public.project_sequences(year, last_number)
  values (yyyy, 1)
  on conflict (year)
  do update set last_number = public.project_sequences.last_number + 1
  returning last_number into next_no;

  return 'WWK-' || yy || lpad(next_no::text, 4, '0');
end;
$$;

alter table public.customers enable row level security;
alter table public.projects enable row level security;
alter table public.drawings enable row level security;
alter table public.photos enable row level security;
alter table public.estimates enable row level security;
alter table public.estimate_items enable row level security;

create policy "authenticated read customers" on public.customers for select to authenticated using (true);
create policy "authenticated write customers" on public.customers for all to authenticated using (true) with check (true);
create policy "authenticated read projects" on public.projects for select to authenticated using (true);
create policy "authenticated write projects" on public.projects for all to authenticated using (true) with check (true);
create policy "authenticated read drawings" on public.drawings for select to authenticated using (true);
create policy "authenticated write drawings" on public.drawings for all to authenticated using (true) with check (true);
create policy "authenticated read photos" on public.photos for select to authenticated using (true);
create policy "authenticated write photos" on public.photos for all to authenticated using (true) with check (true);
create policy "authenticated read estimates" on public.estimates for select to authenticated using (true);
create policy "authenticated write estimates" on public.estimates for all to authenticated using (true) with check (true);
create policy "authenticated write estimate items" on public.estimate_items for all to authenticated using (true) with check (true);
