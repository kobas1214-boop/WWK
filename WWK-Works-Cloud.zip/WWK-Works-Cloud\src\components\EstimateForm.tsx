import { Download, Plus } from "lucide-react";

export function EstimateForm() {
  return (
    <div className="panel">
      <div className="form-grid">
        <div className="field">
          <label>案件番号</label>
          <input defaultValue="WWK-260001" />
        </div>
        <div className="field">
          <label>件名</label>
          <input defaultValue="壁面収納 製作一式" />
        </div>
        <div className="field">
          <label>有効期限</label>
          <input type="date" defaultValue="2026-06-30" />
        </div>
        <div className="field">
          <label>税率</label>
          <select defaultValue="10">
            <option value="10">10%</option>
            <option value="8">8%</option>
          </select>
        </div>
      </div>
      <table className="table" style={{ marginTop: 14 }}>
        <thead>
          <tr>
            <th>品目</th>
            <th>数量</th>
            <th>単価</th>
            <th>金額</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>材料費 ウォールナット</td>
            <td>1</td>
            <td>380,000</td>
            <td>380,000</td>
          </tr>
          <tr>
            <td>加工・組立</td>
            <td>1</td>
            <td>620,000</td>
            <td>620,000</td>
          </tr>
        </tbody>
      </table>
      <div className="actions" style={{ marginTop: 14 }}>
        <button className="button">
          <Plus size={17} aria-hidden />
          明細追加
        </button>
        <button className="button primary">
          <Download size={17} aria-hidden />
          PDF出力
        </button>
      </div>
    </div>
  );
}
