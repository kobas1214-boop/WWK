export type ProjectStatus = "見積中" | "受注" | "製作中" | "納品済";
export type DrawingType = "PDF" | "DXF" | "DWG" | "JPEG" | "PNG";
export type PhotoStage = "製作前" | "製作中" | "完成後";

export type Customer = {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
};

export type Project = {
  id: string;
  projectNo: string;
  customerName: string;
  productName: string;
  woodSpecies: string;
  status: ProjectStatus;
  dueDate: string;
  estimateTotal: number;
};

export type Drawing = {
  id: string;
  projectNo: string;
  fileName: string;
  type: DrawingType;
  productName: string;
  woodSpecies: string;
  uploadedAt: string;
};
