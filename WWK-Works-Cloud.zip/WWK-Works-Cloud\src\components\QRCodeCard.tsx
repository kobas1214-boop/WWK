"use client";

import { QRCodeSVG } from "qrcode.react";

export function QRCodeCard({ projectNo }: { projectNo: string }) {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const url = `${baseUrl}/projects/${projectNo}`;

  return (
    <div className="panel">
      <h2>QRコード</h2>
      <QRCodeSVG value={url} size={188} level="M" includeMargin />
      <p className="muted">スマホで読み取ると案件図面を開きます。</p>
    </div>
  );
}
