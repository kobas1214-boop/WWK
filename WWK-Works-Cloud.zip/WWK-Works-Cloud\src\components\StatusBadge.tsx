import type { ProjectStatus } from "@/lib/types";

const classNameByStatus: Record<ProjectStatus, string> = {
  見積中: "estimate",
  受注: "ordered",
  製作中: "production",
  納品済: "delivered"
};

export function StatusBadge({ status }: { status: ProjectStatus }) {
  return <span className={`badge ${classNameByStatus[status]}`}>{status}</span>;
}
