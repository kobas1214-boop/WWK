import type { Customer, Drawing, Project } from "./types";

export const projects: Project[] = [
  {
    id: "p1",
    projectNo: "WWK-260001",
    customerName: "青山邸",
    productName: "壁面収納",
    woodSpecies: "ウォールナット",
    status: "製作中",
    dueDate: "2026-07-15",
    estimateTotal: 1280000
  },
  {
    id: "p2",
    projectNo: "WWK-260002",
    customerName: "株式会社森住建",
    productName: "造作建具",
    woodSpecies: "ホワイトオーク",
    status: "受注",
    dueDate: "2026-07-28",
    estimateTotal: 860000
  },
  {
    id: "p3",
    projectNo: "WWK-260003",
    customerName: "代官山カフェ",
    productName: "カウンター什器",
    woodSpecies: "タモ",
    status: "見積中",
    dueDate: "2026-08-05",
    estimateTotal: 540000
  }
];

export const customers: Customer[] = [
  { id: "c1", companyName: "青山邸", contactName: "青山様", phone: "03-0000-0001", email: "aoyama@example.com" },
  { id: "c2", companyName: "株式会社森住建", contactName: "森田様", phone: "03-0000-0002", email: "morita@example.com" },
  { id: "c3", companyName: "代官山カフェ", contactName: "小川様", phone: "03-0000-0003", email: "ogawa@example.com" }
];

export const drawings: Drawing[] = [
  { id: "d1", projectNo: "WWK-260001", fileName: "wall-storage-v3.pdf", type: "PDF", productName: "壁面収納", woodSpecies: "ウォールナット", uploadedAt: "2026-06-05" },
  { id: "d2", projectNo: "WWK-260002", fileName: "door-frame.dxf", type: "DXF", productName: "造作建具", woodSpecies: "ホワイトオーク", uploadedAt: "2026-06-06" },
  { id: "d3", projectNo: "WWK-260003", fileName: "counter-plan.png", type: "PNG", productName: "カウンター什器", woodSpecies: "タモ", uploadedAt: "2026-06-08" }
];

export const formatYen = (value: number) => new Intl.NumberFormat("ja-JP", { style: "currency", currency: "JPY" }).format(value);
