import { UploadCloud } from "lucide-react";

export function UploadPanel() {
  return (
    <div className="panel">
      <h2>図面アップロード</h2>
      <div className="field">
        <label>対応形式 PDF / DXF / DWG / JPEG / PNG</label>
        <input type="file" accept=".pdf,.dxf,.dwg,.jpg,.jpeg,.png" />
      </div>
      <div className="actions" style={{ marginTop: 12 }}>
        <button className="button primary">
          <UploadCloud size={17} aria-hidden />
          保存
        </button>
      </div>
    </div>
  );
}
