import OpenAI from "openai";
import { z } from "zod";

export const drawingAnalysisSchema = z.object({
  dimensions: z.array(z.string()).default([]),
  woodSpecies: z.array(z.string()).default([]),
  productName: z.string().optional(),
  notes: z.array(z.string()).default([])
});

export type DrawingAnalysis = z.infer<typeof drawingAnalysisSchema>;

export async function analyzeDrawingText(text: string): Promise<DrawingAnalysis> {
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const model = process.env.OPENAI_MODEL || "gpt-4.1";

  const response = await client.chat.completions.create({
    model,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content:
          "You extract woodworking drawing information. Return JSON with dimensions, woodSpecies, productName, and notes. Use Japanese values when present."
      },
      { role: "user", content: text.slice(0, 20000) }
    ]
  });

  const content = response.choices[0]?.message.content || "{}";
  return drawingAnalysisSchema.parse(JSON.parse(content));
}
