insert into storage.buckets (id, name, public)
values
  ('drawings', 'drawings', false),
  ('photos', 'photos', false),
  ('estimates', 'estimates', false)
on conflict (id) do nothing;

create policy "authenticated read drawings files"
on storage.objects for select to authenticated
using (bucket_id = 'drawings');

create policy "authenticated upload drawings files"
on storage.objects for insert to authenticated
with check (bucket_id = 'drawings');

create policy "authenticated read photos files"
on storage.objects for select to authenticated
using (bucket_id = 'photos');

create policy "authenticated upload photos files"
on storage.objects for insert to authenticated
with check (bucket_id = 'photos');

create policy "authenticated read estimate files"
on storage.objects for select to authenticated
using (bucket_id = 'estimates');

create policy "authenticated upload estimate files"
on storage.objects for insert to authenticated
with check (bucket_id = 'estimates');
